export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAwxo8Bt7ZeYfFLI5WrakbNGtJsskBv3wA",
    authDomain: "oshop-f3445.firebaseapp.com",
    databaseURL: "https://oshop-f3445.firebaseio.com",
    projectId: "oshop-f3445",
    storageBucket: "oshop-f3445.appspot.com",
    messagingSenderId: "223112932947"    
  }
};
